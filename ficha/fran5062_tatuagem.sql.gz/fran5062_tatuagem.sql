-- phpMyAdmin SQL Dump
-- version 5.2.1
-- Host: localhost:3306
-- Banco de dados: `fran5062_tatuagem`
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `genero` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profissao` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `endereco` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hobbies` text COLLATE utf8_unicode_ci,
  `estilo_tatuagem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autorizou_uso_imagem` tinyint(1) DEFAULT NULL,
  `deseja_marcacao` tinyint(1) DEFAULT NULL,
  `instagram_cliente` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `tatuagens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `descricao` text COLLATE utf8_unicode_ci,
  `valor` decimal(10,2) DEFAULT NULL,
  `data_tatuagem` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cliente_id` (`cliente_id`),
  CONSTRAINT `tatuagens_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
COMMIT;
